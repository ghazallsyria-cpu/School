"use client";

import DashboardLayout from "@/components/shared/DashboardLayout";
import { StatCard, Card, Badge } from "@/components/ui/index";
import { Users, ClipboardList, Clock, PenTool, BarChart3, BookOpen, ArrowUpRight, CheckCircle, XCircle } from "lucide-react";

const myClasses = [
  { name: "الصف الأول أ", students: 32, subject: "الرياضيات", lastActivity: "منذ ساعة" },
  { name: "الصف الثاني ب", students: 28, subject: "الرياضيات", lastActivity: "منذ 3 ساعات" },
  { name: "الصف الثالث أ", students: 35, subject: "الرياضيات", lastActivity: "أمس" },
];

const recentSubmissions = [
  { student: "أحمد محمد", homework: "تمارين الجبر", grade: 9.5, max: 10, status: "graded" },
  { student: "خالد عبدالله", homework: "تمارين الجبر", grade: null, max: 10, status: "pending" },
  { student: "محمد العمري", homework: "تمارين الجبر", grade: 8, max: 10, status: "graded" },
  { student: "سالم الحربي", homework: "تمارين الجبر", grade: null, max: 10, status: "pending" },
];

export default function TeacherDashboard() {
  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-up">
        <div className="page-header">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-1 h-8 rounded-full" style={{ background: "linear-gradient(180deg, #f5c518, #a07808)" }} />
            <h1 className="page-title !mb-0">لوحة المعلم</h1>
          </div>
          <p className="page-subtitle mr-4">مرحباً، إليك نظرة عامة على فصولك</p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard title="فصولي" value="3" subtitle="فصول نشطة" icon={<BookOpen size={20} />} color="gold" />
          <StatCard title="طلابي" value="95" subtitle="في جميع الفصول" icon={<Users size={20} />} color="green" />
          <StatCard title="واجبات معلقة" value="8" subtitle="بانتظار التصحيح" icon={<ClipboardList size={20} />} color="red" />
          <StatCard title="اختبارات الأسبوع" value="2" subtitle="اختبار قادم" icon={<PenTool size={20} />} color="white" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card title="فصولي الدراسية" subtitle="الفصول التي أدرسها حالياً"
            action={<button className="text-xs font-bold flex items-center gap-1" style={{ color: "#c9970c" }}>عرض الكل <ArrowUpRight size={13} /></button>}>
            <div className="space-y-3">
              {myClasses.map((cls, i) => (
                <div key={i} className="flex items-center gap-4 p-4 rounded-xl transition-colors cursor-pointer"
                  onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = "hsl(var(--muted))"; }}
                  onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = "transparent"; }}>
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center font-black text-lg flex-shrink-0"
                    style={{ background: "linear-gradient(135deg, #c9970c, #a07808)", color: "#fff" }}>
                    {cls.name[0]}
                  </div>
                  <div className="flex-1">
                    <p className="font-bold text-sm" style={{ color: "hsl(var(--foreground))" }}>{cls.name}</p>
                    <p className="text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>{cls.subject} • {cls.students} طالب</p>
                  </div>
                  <span className="text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>{cls.lastActivity}</span>
                </div>
              ))}
            </div>
          </Card>

          <Card title="آخر التسليمات" subtitle="تسليمات الواجبات الأخيرة">
            <div className="space-y-2">
              {recentSubmissions.map((sub, i) => (
                <div key={i} className="flex items-center gap-3 px-4 py-3 rounded-xl transition-colors cursor-pointer"
                  onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = "hsl(var(--muted))"; }}
                  onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = "transparent"; }}>
                  <div className="flex-shrink-0">
                    {sub.status === "graded"
                      ? <CheckCircle size={18} style={{ color: "#16a34a" }} />
                      : <XCircle size={18} style={{ color: "#c9970c" }} />
                    }
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold truncate" style={{ color: "hsl(var(--foreground))" }}>{sub.student}</p>
                    <p className="text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>{sub.homework}</p>
                  </div>
                  <div className="text-sm font-bold flex-shrink-0" style={{ color: sub.grade ? "#c9970c" : "hsl(var(--muted-foreground))" }}>
                    {sub.grade ? `${sub.grade}/${sub.max}` : "معلق"}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
