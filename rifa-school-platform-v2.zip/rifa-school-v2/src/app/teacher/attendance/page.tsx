"use client";

import { useState } from "react";
import DashboardLayout from "@/components/shared/DashboardLayout";
import { Card, Badge, StatCard } from "@/components/ui/index";
import { CheckCircle, XCircle, Clock, AlertCircle, Save, ChevronLeft, ChevronRight } from "lucide-react";

const mockStudents = [
  { id: "1", name: "أحمد محمد علي", number: "2024001" },
  { id: "2", name: "محمد عبدالله حسن", number: "2024002" },
  { id: "3", name: "عمر خالد محمود", number: "2024003" },
  { id: "4", name: "يوسف سعد الدين", number: "2024004" },
  { id: "5", name: "عبدالرحمن فاروق", number: "2024005" },
  { id: "6", name: "علي حمد النصر", number: "2024006" },
  { id: "7", name: "فهد عبدالعزيز", number: "2024007" },
  { id: "8", name: "سالم محمد القحطاني", number: "2024008" },
  { id: "9", name: "خالد إبراهيم السعد", number: "2024009" },
  { id: "10", name: "تركي ناصر العتيبي", number: "2024010" },
];

type AttendanceStatus = "present" | "absent" | "late" | "excused" | null;

export default function TeacherAttendance() {
  const [selectedClass, setSelectedClass] = useState("الصف الأول أ");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [attendance, setAttendance] = useState<Record<string, AttendanceStatus>>({});
  const [saved, setSaved] = useState(false);

  const setStatus = (studentId: string, status: AttendanceStatus) => {
    setAttendance(prev => ({ ...prev, [studentId]: status }));
    setSaved(false);
  };

  const markAll = (status: AttendanceStatus) => {
    const all: Record<string, AttendanceStatus> = {};
    mockStudents.forEach(s => { all[s.id] = status; });
    setAttendance(all);
    setSaved(false);
  };

  const counts = {
    present: Object.values(attendance).filter(v => v === "present").length,
    absent: Object.values(attendance).filter(v => v === "absent").length,
    late: Object.values(attendance).filter(v => v === "late").length,
    excused: Object.values(attendance).filter(v => v === "excused").length,
  };

  const statusConfig = {
    present: { label: "حاضر", icon: CheckCircle, activeClass: "bg-emerald-500 border-emerald-500 text-white", inactiveClass: "border-gray-200 dark:border-gray-600 text-gray-400 hover:border-emerald-300 hover:text-emerald-500" },
    absent: { label: "غائب", icon: XCircle, activeClass: "bg-red-500 border-red-500 text-white", inactiveClass: "border-gray-200 dark:border-gray-600 text-gray-400 hover:border-red-300 hover:text-red-500" },
    late: { label: "متأخر", icon: Clock, activeClass: "bg-amber-500 border-amber-500 text-white", inactiveClass: "border-gray-200 dark:border-gray-600 text-gray-400 hover:border-amber-300 hover:text-amber-500" },
    excused: { label: "إذن", icon: AlertCircle, activeClass: "bg-blue-500 border-blue-500 text-white", inactiveClass: "border-gray-200 dark:border-gray-600 text-gray-400 hover:border-blue-300 hover:text-blue-500" },
  };

  return (
    <DashboardLayout>
      <div className="space-y-6 max-w-4xl">
        <div>
          <h1 className="page-title">تسجيل الحضور والغياب ✅</h1>
          <p className="page-subtitle">سجّل حضور طلابك بسهولة</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-100 dark:border-emerald-800/30 rounded-2xl p-4 text-center">
            <div className="text-2xl font-black text-emerald-600">{counts.present}</div>
            <div className="text-xs text-emerald-500 font-medium mt-1">حاضر</div>
          </div>
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-800/30 rounded-2xl p-4 text-center">
            <div className="text-2xl font-black text-red-600">{counts.absent}</div>
            <div className="text-xs text-red-500 font-medium mt-1">غائب</div>
          </div>
          <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-100 dark:border-amber-800/30 rounded-2xl p-4 text-center">
            <div className="text-2xl font-black text-amber-600">{counts.late}</div>
            <div className="text-xs text-amber-500 font-medium mt-1">متأخر</div>
          </div>
          <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800/30 rounded-2xl p-4 text-center">
            <div className="text-2xl font-black text-blue-600">{counts.excused}</div>
            <div className="text-xs text-blue-500 font-medium mt-1">إذن</div>
          </div>
        </div>

        {/* Filters */}
        <Card>
          <div className="flex flex-col sm:flex-row gap-3">
            <select value={selectedClass} onChange={(e) => setSelectedClass(e.target.value)}
              className="input-field py-2 sm:w-48">
              <option>الصف الأول أ</option>
              <option>الصف الثاني ب</option>
              <option>الصف الثالث أ</option>
            </select>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)}
              className="input-field py-2 text-left sm:w-48" dir="ltr" />
            <div className="flex gap-2 flex-1 sm:justify-end">
              <button onClick={() => markAll("present")}
                className="flex items-center gap-1.5 px-3 py-2 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-800 rounded-xl text-sm font-semibold hover:bg-emerald-100 transition-colors">
                <CheckCircle size={14} /> كل حاضر
              </button>
              <button onClick={() => setAttendance({})}
                className="flex items-center gap-1.5 px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-xl text-sm font-semibold hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors text-gray-600 dark:text-gray-400">
                إعادة تعيين
              </button>
            </div>
          </div>
        </Card>

        {/* Student List */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
          <div className="px-5 py-3 bg-gray-50 dark:bg-gray-800/50 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between">
            <span className="text-sm font-bold text-gray-700 dark:text-gray-300">{selectedClass} · {mockStudents.length} طالب</span>
            <span className="text-xs text-gray-400">
              {Object.keys(attendance).length} من {mockStudents.length} مسجّل
            </span>
          </div>
          <div className="divide-y divide-gray-50 dark:divide-gray-700/50">
            {mockStudents.map((student, idx) => (
              <div key={student.id}
                className={`flex items-center gap-4 px-5 py-3.5 transition-colors ${attendance[student.id] === "present" ? "bg-emerald-50/50 dark:bg-emerald-900/10" : attendance[student.id] === "absent" ? "bg-red-50/50 dark:bg-red-900/10" : attendance[student.id] === "late" ? "bg-amber-50/50 dark:bg-amber-900/10" : "hover:bg-gray-50 dark:hover:bg-gray-700/30"}`}>
                <div className="text-sm font-bold text-gray-400 w-6 text-center">{idx + 1}</div>
                <div className="w-10 h-10 rounded-xl bg-gray-100 dark:bg-gray-700 flex items-center justify-center text-gray-500 dark:text-gray-400 font-bold text-sm flex-shrink-0">
                  {student.name[0]}
                </div>
                <div className="flex-1">
                  <div className="font-semibold text-gray-800 dark:text-gray-200 text-sm">{student.name}</div>
                  <div className="text-xs text-gray-400">رقم: {student.number}</div>
                </div>
                <div className="flex items-center gap-2">
                  {(["present", "absent", "late", "excused"] as const).map((status) => {
                    const config = statusConfig[status];
                    const Icon = config.icon;
                    const isActive = attendance[student.id] === status;
                    return (
                      <button key={status} onClick={() => setStatus(student.id, isActive ? null : status)}
                        title={config.label}
                        className={`w-9 h-9 rounded-xl border-2 flex items-center justify-center transition-all ${isActive ? config.activeClass : config.inactiveClass}`}>
                        <Icon size={16} />
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Save Button */}
        <div className="flex gap-3">
          <button onClick={() => setSaved(true)}
            className={`flex-1 flex items-center justify-center gap-2 py-3.5 rounded-xl font-bold text-base transition-all ${saved ? "bg-emerald-500 text-white" : "btn-primary"}`}>
            {saved ? <><CheckCircle size={18} /> تم الحفظ!</> : <><Save size={18} /> حفظ الحضور</>}
          </button>
        </div>
      </div>
    </DashboardLayout>
  );
}
