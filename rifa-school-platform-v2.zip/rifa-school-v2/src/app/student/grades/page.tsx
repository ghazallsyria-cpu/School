"use client";
import DashboardLayout from "@/components/shared/DashboardLayout";
import { Card, ProgressBar, Badge } from "@/components/ui/index";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { Award, TrendingUp } from "lucide-react";

const grades = [
  { subject: "رياضيات", items: [{ name: "واجب 1", grade: 18, max: 20 }, { name: "اختبار قصير", grade: 8, max: 10 }, { name: "الاختبار الشهري", grade: 42, max: 50 }], final: 87, teacher: "أ. محمد أحمد" },
  { subject: "اللغة العربية", items: [{ name: "تقرير قراءة", grade: 14, max: 15 }, { name: "إملاء", grade: 9, max: 10 }, { name: "الاختبار الشهري", grade: 46, max: 50 }], final: 92, teacher: "أ. فاطمة علي" },
  { subject: "العلوم", items: [{ name: "تقرير مختبر", grade: 22, max: 25 }, { name: "اختبار قصير", grade: 7, max: 10 }, { name: "الاختبار الشهري", grade: 38, max: 50 }], final: 78, teacher: "أ. خالد إبراهيم" },
  { subject: "اللغة الإنجليزية", items: [{ name: "Grammar Test", grade: 16, max: 20 }, { name: "Vocabulary", grade: 8, max: 10 }, { name: "Monthly Exam", grade: 34, max: 50 }], final: 70, teacher: "أ. سارة محمود" },
  { subject: "التاريخ", items: [{ name: "بحث", grade: 18, max: 20 }, { name: "اختبار قصير", grade: 9, max: 10 }, { name: "الاختبار الشهري", grade: 43, max: 50 }], final: 85, teacher: "أ. عمر حسن" },
];

const chartData = grades.map(g => ({ name: g.subject.split(" ")[0], grade: g.final }));

const getLabel = (pct: number) => pct >= 90 ? ["ممتاز", "success"] : pct >= 75 ? ["جيد جداً", "info"] : pct >= 60 ? ["جيد", "warning"] : ["مقبول", "danger"];

export default function StudentGrades() {
  const avg = Math.round(grades.reduce((s, g) => s + g.final, 0) / grades.length);
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="page-title">درجاتي 🏆</h1>
          <p className="page-subtitle">سجل أدائي الأكاديمي للفصل الدراسي الثاني</p>
        </div>

        {/* Overall */}
        <div className="bg-gradient-to-l from-primary-700 to-primary-500 rounded-2xl p-6 text-white flex items-center gap-6">
          <div className="w-20 h-20 rounded-2xl bg-white/20 border-2 border-white/30 flex items-center justify-center flex-shrink-0">
            <div className="text-center"><div className="text-3xl font-black">{avg}%</div></div>
          </div>
          <div>
            <div className="text-2xl font-black mb-1">المعدل العام</div>
            <div className="text-blue-100 text-sm">{avg >= 90 ? "ممتاز 🌟" : avg >= 75 ? "جيد جداً ✨" : avg >= 60 ? "جيد 👍" : "مقبول"}</div>
            <div className="text-blue-200 text-xs mt-1">الفصل الدراسي الثاني 2024-2025</div>
          </div>
          <div className="mr-auto hidden sm:flex items-center gap-2 bg-white/15 rounded-xl px-4 py-2">
            <TrendingUp size={18} />
            <span className="font-bold text-sm">+3.2% عن الفصل الماضي</span>
          </div>
        </div>

        {/* Chart */}
        <Card title="مقارنة الدرجات حسب المادة 📊">
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="name" tick={{ fontSize: 11, fontFamily: "Cairo" }} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 11 }} />
              <Tooltip contentStyle={{ fontFamily: "Cairo", borderRadius: "12px" }} formatter={(v: number) => [`${v}%`, "الدرجة"]} />
              <Bar dataKey="grade" radius={[6, 6, 0, 0]}
                fill="#0ea5e9"
                label={{ position: "top", fontSize: 10, fill: "#6b7280" }} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* Subject Breakdown */}
        <div className="space-y-4">
          {grades.map(g => {
            const [label, variant] = getLabel(g.final);
            return (
              <div key={g.subject} className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-sm overflow-hidden">
                <div className="flex items-center justify-between px-5 py-4 border-b border-gray-50 dark:border-gray-700">
                  <div>
                    <h3 className="font-bold text-gray-900 dark:text-white">{g.subject}</h3>
                    <p className="text-xs text-gray-400 mt-0.5">{g.teacher}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge variant={variant as any}>{label}</Badge>
                    <span className={`text-2xl font-black ${g.final >= 85 ? "text-emerald-600" : g.final >= 70 ? "text-blue-600" : g.final >= 60 ? "text-amber-600" : "text-red-500"}`}>{g.final}%</span>
                  </div>
                </div>
                <div className="px-5 py-3">
                  <ProgressBar value={g.final} color={g.final >= 85 ? "green" : g.final >= 70 ? "blue" : g.final >= 60 ? "yellow" : "red"} showLabel={false} />
                </div>
                <div className="px-5 pb-4">
                  <div className="grid grid-cols-3 gap-2">
                    {g.items.map((item, i) => (
                      <div key={i} className="text-center bg-gray-50 dark:bg-gray-700 rounded-xl p-2.5">
                        <div className={`font-black text-sm ${(item.grade / item.max) >= 0.8 ? "text-emerald-600" : (item.grade / item.max) >= 0.6 ? "text-amber-600" : "text-red-500"}`}>
                          {item.grade}/{item.max}
                        </div>
                        <div className="text-[10px] text-gray-400 mt-0.5 truncate">{item.name}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </DashboardLayout>
  );
}
