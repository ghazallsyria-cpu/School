"use client";

import DashboardLayout from "@/components/shared/DashboardLayout";
import { StatCard, Card, Badge } from "@/components/ui/index";
import { Award, BookOpen, ClipboardList, Calendar, Clock, PenTool, Bell, TrendingUp, ArrowUpRight } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, Radar, PolarGrid, PolarAngleAxis } from "recharts";

const gradesTrend = [
  { week: "الأسبوع 1", grade: 72 },
  { week: "الأسبوع 2", grade: 78 },
  { week: "الأسبوع 3", grade: 75 },
  { week: "الأسبوع 4", grade: 82 },
  { week: "الأسبوع 5", grade: 88 },
  { week: "الأسبوع 6", grade: 85 },
];

const subjectRadar = [
  { subject: "رياضيات", grade: 82 },
  { subject: "عربي", grade: 90 },
  { subject: "علوم", grade: 75 },
  { subject: "إنجليزي", grade: 68 },
  { subject: "تاريخ", grade: 85 },
];

const upcomingHomework = [
  { subject: "الرياضيات", title: "حل تمارين الفصل الثالث", due: "غداً", urgent: true },
  { subject: "اللغة العربية", title: "تلخيص القصيدة", due: "بعد غد", urgent: false },
  { subject: "العلوم", title: "تقرير عن الخلية", due: "الأحد", urgent: false },
];

const upcomingExams = [
  { subject: "الرياضيات", date: "الأحد 15 فبراير", time: "09:00", chapters: "الفصل 3-4" },
  { subject: "العلوم", date: "الثلاثاء 17 فبراير", time: "11:00", chapters: "الأحياء" },
];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload?.length) {
    return (
      <div className="rounded-xl p-3 shadow-xl text-sm" style={{ background: "#0a0a0a", border: "1px solid rgba(184,134,11,0.3)", color: "#fff" }}>
        <p className="font-bold mb-1" style={{ color: "#c9970c" }}>{label}</p>
        <p>الدرجة: <span style={{ color: "#f5c518" }}>{payload[0].value}%</span></p>
      </div>
    );
  }
  return null;
};

export default function StudentDashboard() {
  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-up">
        {/* Header */}
        <div className="page-header">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-1 h-8 rounded-full" style={{ background: "linear-gradient(180deg, #f5c518, #a07808)" }} />
            <h1 className="page-title !mb-0">لوحة الطالب</h1>
          </div>
          <p className="page-subtitle mr-4">مرحباً! إليك ملخص أدائك الدراسي</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard title="متوسط الدرجات" value="85%" subtitle="هذا الفصل" icon={<Award size={20} />} color="gold" trend={{ value: 7, label: "تحسن" }} />
          <StatCard title="الدروس المكتملة" value="24" subtitle="من أصل 30" icon={<BookOpen size={20} />} color="green" />
          <StatCard title="الواجبات المعلقة" value="3" subtitle="يجب التسليم قريباً" icon={<ClipboardList size={20} />} color="red" />
          <StatCard title="نسبة الحضور" value="96%" subtitle="هذا الفصل" icon={<Clock size={20} />} color="gold" />
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card title="تطور الأداء" subtitle="متوسط درجاتك الأسبوعية">
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={gradesTrend} margin={{ top: 5, right: 0, left: -20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(184,134,11,0.08)" />
                <XAxis dataKey="week" tick={{ fontSize: 11, fontFamily: "Cairo", fill: "#888" }} />
                <YAxis domain={[60, 100]} tick={{ fontSize: 11, fill: "#888" }} />
                <Tooltip content={<CustomTooltip />} />
                <Line type="monotone" dataKey="grade" stroke="#c9970c" strokeWidth={2.5} dot={{ fill: "#c9970c", r: 4 }} activeDot={{ r: 6, fill: "#f5c518" }} />
              </LineChart>
            </ResponsiveContainer>
          </Card>

          <Card title="الأداء بالمواد" subtitle="درجاتك في كل مادة">
            <ResponsiveContainer width="100%" height={220}>
              <RadarChart data={subjectRadar}>
                <PolarGrid stroke="rgba(184,134,11,0.15)" />
                <PolarAngleAxis dataKey="subject" tick={{ fontSize: 11, fontFamily: "Cairo", fill: "#888" }} />
                <Radar name="الدرجة" dataKey="grade" stroke="#c9970c" fill="rgba(184,134,11,0.15)" strokeWidth={2} />
                <Tooltip contentStyle={{ background: "#0a0a0a", border: "1px solid rgba(184,134,11,0.3)", borderRadius: "12px", color: "#fff", fontFamily: "Cairo" }} />
              </RadarChart>
            </ResponsiveContainer>
          </Card>
        </div>

        {/* Homework & Exams Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card title="الواجبات القادمة" subtitle="المطلوب تسليمه قريباً"
            action={<button className="text-xs font-bold flex items-center gap-1" style={{ color: "#c9970c" }}>الكل <ArrowUpRight size={13} /></button>}>
            <div className="space-y-3">
              {upcomingHomework.map((hw, i) => (
                <div key={i} className="flex items-start gap-3 p-4 rounded-xl transition-colors cursor-pointer"
                  onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = "hsl(var(--muted))"; }}
                  onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = "transparent"; }}>
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center text-base flex-shrink-0"
                    style={{ background: "rgba(184,134,11,0.08)" }}>📋</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <p className="text-sm font-bold truncate" style={{ color: "hsl(var(--foreground))" }}>{hw.title}</p>
                      {hw.urgent && <Badge variant="danger">عاجل</Badge>}
                    </div>
                    <p className="text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>{hw.subject} • تسليم {hw.due}</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card title="الاختبارات القادمة" subtitle="الاختبارات المرتقبة"
            action={<button className="text-xs font-bold flex items-center gap-1" style={{ color: "#c9970c" }}>الكل <ArrowUpRight size={13} /></button>}>
            <div className="space-y-3">
              {upcomingExams.map((exam, i) => (
                <div key={i} className="p-4 rounded-xl border transition-all cursor-pointer"
                  style={{ borderColor: "rgba(184,134,11,0.2)", background: "rgba(184,134,11,0.03)" }}
                  onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = "rgba(184,134,11,0.06)"; }}
                  onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = "rgba(184,134,11,0.03)"; }}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-sm" style={{ color: "hsl(var(--foreground))" }}>{exam.subject}</span>
                    <Badge variant="gold">{exam.time}</Badge>
                  </div>
                  <p className="text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>{exam.date}</p>
                  <p className="text-xs mt-1" style={{ color: "hsl(var(--muted-foreground))" }}>المحتوى: {exam.chapters}</p>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
