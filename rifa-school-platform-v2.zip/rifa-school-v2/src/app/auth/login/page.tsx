"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";
import { Eye, EyeOff, Shield, BookOpen, GraduationCap, Users, Star, Sparkles } from "lucide-react";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const { signIn } = useAuth();
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    const { error: err } = await signIn(email, password);
    if (err) {
      setError("بيانات الدخول غير صحيحة. يرجى المحاولة مرة أخرى.");
      setLoading(false);
      return;
    }
    const savedRole = localStorage.getItem("userRole") || "student";
    const routes: Record<string, string> = { admin: "/admin", teacher: "/teacher", student: "/student", parent: "/parent" };
    router.push(routes[savedRole] || "/student");
  };

  const demoAccounts = [
    { role: "مدير النظام", email: "admin@rifa.edu", pass: "admin123", icon: Shield, desc: "صلاحيات كاملة" },
    { role: "معلم", email: "teacher@rifa.edu", pass: "teacher123", icon: BookOpen, desc: "إدارة الفصول" },
    { role: "طالب", email: "student@rifa.edu", pass: "student123", icon: GraduationCap, desc: "متابعة الدراسة" },
    { role: "ولي أمر", email: "parent@rifa.edu", pass: "parent123", icon: Users, desc: "متابعة الأبناء" },
  ];

  return (
    <div className="min-h-screen flex" dir="rtl" style={{ background: "#f5f5f3" }}>

      {/* Right Panel — Login */}
      <div className="flex-1 flex flex-col items-center justify-center p-6 lg:p-16 relative">
        {/* Background pattern */}
        <div className="absolute inset-0 opacity-5 pointer-events-none"
          style={{
            backgroundImage: `radial-gradient(circle at 20px 20px, #b8860b 1px, transparent 0)`,
            backgroundSize: "40px 40px",
          }}
        />

        <div className="w-full max-w-md relative z-10">
          {/* Mobile Logo */}
          <div className="lg:hidden text-center mb-10">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl mb-4"
              style={{ background: "linear-gradient(135deg, #c9970c, #a07808)", boxShadow: "0 8px 24px rgba(184,134,11,0.35)" }}>
              <span className="text-white text-3xl font-black">ر</span>
            </div>
            <h1 className="text-2xl font-black" style={{ color: "#0a0a0a" }}>مدرسة الرفعة النموذجية</h1>
          </div>

          {/* Form Card */}
          <div className="rounded-3xl p-8 shadow-xl" style={{ background: "#ffffff", border: "1px solid #e8e8e8" }}>
            <div className="mb-8">
              <h2 className="text-3xl font-black mb-2" style={{ color: "#0a0a0a" }}>
                أهلاً بعودتك
              </h2>
              <p style={{ color: "#888" }} className="text-sm">سجّل دخولك للوصول إلى المنصة التعليمية</p>
            </div>

            {error && (
              <div className="mb-6 p-4 rounded-xl text-sm font-medium flex items-center gap-2"
                style={{ background: "rgba(220,38,38,0.06)", border: "1px solid rgba(220,38,38,0.2)", color: "#dc2626" }}>
                <span>⚠️</span> {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="block text-sm font-bold mb-2" style={{ color: "#333" }}>
                  البريد الإلكتروني
                </label>
                <input
                  type="email" value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="input-field"
                  placeholder="example@rifa.edu"
                  dir="ltr" required
                />
              </div>
              <div>
                <label className="block text-sm font-bold mb-2" style={{ color: "#333" }}>
                  كلمة المرور
                </label>
                <div className="relative">
                  <input
                    type={showPass ? "text" : "password"} value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="input-field pr-12"
                    placeholder="••••••••" dir="ltr" required
                  />
                  <button type="button" onClick={() => setShowPass(!showPass)}
                    className="absolute left-3 top-1/2 -translate-y-1/2 transition-colors"
                    style={{ color: "#888" }}>
                    {showPass ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>
              <button type="submit" disabled={loading} className="btn-primary w-full py-4 text-base mt-2 flex items-center justify-center gap-2">
                {loading ? (
                  <><div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />جاري التحميل...</>
                ) : (
                  <><Sparkles size={18} />دخول إلى المنصة</>
                )}
              </button>
            </form>

            {/* Divider */}
            <div className="my-7 flex items-center gap-3">
              <div className="flex-1 h-px" style={{ background: "#e8e8e8" }} />
              <span className="text-xs font-semibold" style={{ color: "#bbb" }}>حسابات تجريبية</span>
              <div className="flex-1 h-px" style={{ background: "#e8e8e8" }} />
            </div>

            {/* Demo Accounts */}
            <div className="grid grid-cols-2 gap-3">
              {demoAccounts.map((acc) => {
                const Icon = acc.icon;
                return (
                  <button key={acc.role} type="button"
                    onClick={() => { setEmail(acc.email); setPassword(acc.pass); }}
                    className="flex flex-col items-start gap-1 px-4 py-3 rounded-xl border transition-all duration-200 text-right hover:shadow-md"
                    style={{
                      background: "#fafafa",
                      borderColor: "#e8e8e8",
                      color: "#333"
                    }}
                    onMouseEnter={(e) => {
                      (e.currentTarget as HTMLElement).style.borderColor = "rgba(184,134,11,0.5)";
                      (e.currentTarget as HTMLElement).style.background = "rgba(184,134,11,0.04)";
                    }}
                    onMouseLeave={(e) => {
                      (e.currentTarget as HTMLElement).style.borderColor = "#e8e8e8";
                      (e.currentTarget as HTMLElement).style.background = "#fafafa";
                    }}
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg flex items-center justify-center"
                        style={{ background: "linear-gradient(135deg, #c9970c, #a07808)" }}>
                        <Icon size={14} className="text-white" />
                      </div>
                      <span className="font-bold text-xs">{acc.role}</span>
                    </div>
                    <span className="text-xs" style={{ color: "#aaa" }}>{acc.desc}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <p className="text-center text-xs mt-6" style={{ color: "#bbb" }}>
            © {new Date().getFullYear()} مدرسة الرفعة النموذجية — جميع الحقوق محفوظة
          </p>
        </div>
      </div>

      {/* Left Panel — Dark Decorative */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden flex-col items-center justify-center"
        style={{ background: "#080808" }}>
        {/* Gold geometric pattern */}
        <div className="absolute inset-0"
          style={{
            backgroundImage: `radial-gradient(circle at 30px 30px, rgba(184,134,11,0.08) 1px, transparent 0)`,
            backgroundSize: "60px 60px",
          }}
        />
        {/* Decorative rings */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full"
          style={{ border: "1px solid rgba(184,134,11,0.1)" }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[350px] h-[350px] rounded-full"
          style={{ border: "1px solid rgba(184,134,11,0.15)" }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[200px] h-[200px] rounded-full"
          style={{ border: "1px solid rgba(184,134,11,0.2)" }} />

        <div className="relative z-10 text-center p-12 max-w-md">
          {/* Emblem */}
          <div className="w-28 h-28 rounded-3xl mx-auto mb-10 flex items-center justify-center"
            style={{
              background: "linear-gradient(135deg, #c9970c 0%, #a07808 100%)",
              boxShadow: "0 0 40px rgba(184,134,11,0.4), 0 16px 40px rgba(0,0,0,0.4)"
            }}>
            <div className="text-center">
              <div className="text-white text-4xl font-black">ر</div>
            </div>
          </div>

          <h1 className="text-4xl font-black text-white mb-3 leading-tight">
            مدرسة الرفعة
            <br />
            <span className="gold-text">النموذجية</span>
          </h1>
          <p className="text-lg mb-2 font-semibold" style={{ color: "#888" }}>متوسط ثانوي بنين</p>
          <p className="text-sm mb-12" style={{ color: "#555" }}>المنصة التعليمية الرقمية المتكاملة</p>

          {/* Stats */}
          <div className="grid grid-cols-2 gap-4">
            {[
              { label: "طالب", value: "1,200+", icon: "🎓" },
              { label: "معلم", value: "80+", icon: "👨‍🏫" },
              { label: "مادة دراسية", value: "24+", icon: "📚" },
              { label: "فصل دراسي", value: "36+", icon: "🏫" },
            ].map((stat) => (
              <div key={stat.label} className="rounded-2xl p-5 text-center"
                style={{
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(184,134,11,0.2)"
                }}>
                <div className="text-2xl mb-2">{stat.icon}</div>
                <div className="text-2xl font-black" style={{
                  background: "linear-gradient(135deg, #f5c518, #c9970c)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent"
                }}>{stat.value}</div>
                <div className="text-xs mt-1 font-medium" style={{ color: "#666" }}>{stat.label}</div>
              </div>
            ))}
          </div>

          {/* Features */}
          <div className="mt-10 flex flex-wrap justify-center gap-2">
            {["اختبارات ذكية", "تتبع الحضور", "تقارير مفصلة", "إشعارات فورية"].map((f) => (
              <span key={f} className="px-3 py-1.5 rounded-full text-xs font-semibold"
                style={{ background: "rgba(184,134,11,0.12)", color: "#c9970c", border: "1px solid rgba(184,134,11,0.2)" }}>
                {f}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
