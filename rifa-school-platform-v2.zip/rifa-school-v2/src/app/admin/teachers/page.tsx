"use client";
import { useState } from "react";
import DashboardLayout from "@/components/shared/DashboardLayout";
import { Card, Badge, Modal, StatCard } from "@/components/ui/index";
import { Plus, Search, Edit, Trash2, Eye, Users, BookOpen, Award, Phone } from "lucide-react";

const mockTeachers = [
  { id: "1", name: "أ. محمد أحمد السيد", email: "m.ahmed@rifa.edu", subject: "رياضيات", classes: ["الصف الأول أ", "الصف الثاني ب"], students: 68, avgScore: 82, phone: "+966501234567", hireDate: "2020-09-01", status: "active" },
  { id: "2", name: "أ. فاطمة علي محمد", email: "f.ali@rifa.edu", subject: "اللغة العربية", classes: ["الصف الأول ب", "الصف الثالث أ"], students: 72, avgScore: 88, phone: "+966507654321", hireDate: "2019-09-01", status: "active" },
  { id: "3", name: "أ. خالد إبراهيم النصر", email: "k.ibrahim@rifa.edu", subject: "العلوم", classes: ["الصف الثاني أ"], students: 35, avgScore: 75, phone: "+966509876543", hireDate: "2021-09-01", status: "active" },
  { id: "4", name: "أ. سارة محمود أحمد", email: "s.mahmoud@rifa.edu", subject: "اللغة الإنجليزية", classes: ["الصف الأول أ", "الصف الأول ب"], students: 70, avgScore: 79, phone: "+966502345678", hireDate: "2022-01-01", status: "active" },
  { id: "5", name: "أ. عمر حسن القحطاني", email: "o.hassan@rifa.edu", subject: "التاريخ", classes: ["الصف الثالث أ", "الصف الثالث ب"], students: 74, avgScore: 84, phone: "+966503456789", hireDate: "2018-09-01", status: "active" },
];

export default function AdminTeachers() {
  const [search, setSearch] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [selected, setSelected] = useState<typeof mockTeachers[0] | null>(null);

  const filtered = mockTeachers.filter(t => t.name.includes(search) || t.subject.includes(search) || t.email.includes(search));

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="page-title">إدارة المعلمين 👨‍🏫</h1>
            <p className="page-subtitle">إجمالي {mockTeachers.length} معلم في المدرسة</p>
          </div>
          <button onClick={() => setShowAdd(true)} className="flex items-center gap-2 btn-primary text-sm py-2.5">
            <Plus size={16} /> إضافة معلم
          </button>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard title="إجمالي المعلمين" value="82" icon={<Users size={20} />} color="blue" />
          <StatCard title="المواد المُدرَّسة" value="12" icon={<BookOpen size={20} />} color="green" />
          <StatCard title="متوسط الأداء" value="83%" icon={<Award size={20} />} color="gold" />
          <StatCard title="جدد هذا العام" value="5" icon={<Users size={20} />} color="purple" />
        </div>

        <Card>
          <div className="relative">
            <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input type="search" placeholder="البحث عن معلم..." value={search} onChange={e => setSearch(e.target.value)} className="input-field pr-9 py-2" />
          </div>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map(t => (
            <div key={t.id} className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-sm card-hover p-5">
              <div className="flex items-start gap-3 mb-4">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white font-black text-lg flex-shrink-0">
                  {t.name.split(" ")[1]?.[0] || t.name[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-gray-900 dark:text-white text-sm truncate">{t.name}</h3>
                  <p className="text-xs text-gray-400 truncate">{t.email}</p>
                  <Badge variant="info" className="mt-1">{t.subject}</Badge>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2 mb-4">
                {[{ label: "الفصول", value: t.classes.length }, { label: "الطلاب", value: t.students }, { label: "المتوسط", value: `${t.avgScore}%` }].map(s => (
                  <div key={s.label} className="text-center bg-gray-50 dark:bg-gray-700 rounded-xl p-2">
                    <div className="font-black text-gray-800 dark:text-gray-100 text-sm">{s.value}</div>
                    <div className="text-[10px] text-gray-400 mt-0.5">{s.label}</div>
                  </div>
                ))}
              </div>
              <div className="flex gap-2">
                <button onClick={() => setSelected(t)} className="flex-1 flex items-center justify-center gap-1 py-2 text-xs font-semibold border border-gray-200 dark:border-gray-600 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"><Eye size={13} /> عرض</button>
                <button className="flex-1 flex items-center justify-center gap-1 py-2 text-xs font-semibold bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 rounded-xl hover:bg-primary-100 transition-colors border border-primary-100 dark:border-primary-800"><Edit size={13} /> تعديل</button>
                <button className="px-3 py-2 bg-red-50 dark:bg-red-900/20 text-red-400 rounded-xl hover:bg-red-100 transition-colors border border-red-100 dark:border-red-800"><Trash2 size={13} /></button>
              </div>
            </div>
          ))}
        </div>

        <Modal open={showAdd} onClose={() => setShowAdd(false)} title="إضافة معلم جديد" size="lg">
          <form className="space-y-4" onSubmit={e => { e.preventDefault(); setShowAdd(false); }}>
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2"><label className="block text-sm font-semibold mb-1.5 text-gray-700 dark:text-gray-300">الاسم الكامل *</label><input type="text" className="input-field" placeholder="أ. محمد أحمد" required /></div>
              <div><label className="block text-sm font-semibold mb-1.5 text-gray-700 dark:text-gray-300">البريد الإلكتروني *</label><input type="email" className="input-field text-left" dir="ltr" required /></div>
              <div><label className="block text-sm font-semibold mb-1.5 text-gray-700 dark:text-gray-300">رقم الجوال</label><input type="tel" className="input-field text-left" dir="ltr" /></div>
              <div><label className="block text-sm font-semibold mb-1.5 text-gray-700 dark:text-gray-300">التخصص *</label><select className="input-field" required><option value="">اختر المادة</option><option>رياضيات</option><option>عربي</option><option>علوم</option><option>إنجليزي</option></select></div>
              <div><label className="block text-sm font-semibold mb-1.5 text-gray-700 dark:text-gray-300">تاريخ التعيين</label><input type="date" className="input-field text-left" dir="ltr" /></div>
              <div className="col-span-2"><label className="block text-sm font-semibold mb-1.5 text-gray-700 dark:text-gray-300">كلمة المرور *</label><input type="password" className="input-field text-left" dir="ltr" required /></div>
            </div>
            <div className="flex gap-3 pt-2">
              <button type="submit" className="flex-1 btn-primary py-3">إضافة المعلم</button>
              <button type="button" onClick={() => setShowAdd(false)} className="flex-1 border border-gray-200 dark:border-gray-600 rounded-xl py-3 text-sm font-semibold hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">إلغاء</button>
            </div>
          </form>
        </Modal>

        {selected && (
          <Modal open={!!selected} onClose={() => setSelected(null)} title={`ملف المعلم`} size="md">
            <div className="space-y-4">
              <div className="flex items-center gap-4 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-2xl">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white text-2xl font-black">{selected.name.split(" ")[1]?.[0]}</div>
                <div><h3 className="text-xl font-black text-gray-900 dark:text-white">{selected.name}</h3><p className="text-gray-500 text-sm">{selected.subject}</p></div>
              </div>
              <div className="space-y-2 text-sm">
                {[["البريد", selected.email], ["الجوال", selected.phone], ["تاريخ التعيين", selected.hireDate], ["الفصول", selected.classes.join("، ")]].map(([k, v]) => (
                  <div key={k} className="flex justify-between py-2 border-b border-gray-100 dark:border-gray-700"><span className="text-gray-500">{k}</span><span className="font-semibold text-gray-800 dark:text-gray-200">{v}</span></div>
                ))}
              </div>
            </div>
          </Modal>
        )}
      </div>
    </DashboardLayout>
  );
}
