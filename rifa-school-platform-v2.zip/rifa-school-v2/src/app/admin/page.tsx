"use client";

import DashboardLayout from "@/components/shared/DashboardLayout";
import { StatCard, Card, Badge } from "@/components/ui/index";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell, AreaChart, Area
} from "recharts";
import { GraduationCap, Users, BookOpen, ClipboardList, TrendingUp, Award, Bell, Clock, PenTool, UserCheck, ArrowUpRight } from "lucide-react";

const attendanceData = [
  { day: "الأحد", present: 280, absent: 20 },
  { day: "الاثنين", present: 295, absent: 15 },
  { day: "الثلاثاء", present: 270, absent: 30 },
  { day: "الأربعاء", present: 288, absent: 12 },
  { day: "الخميس", present: 275, absent: 25 },
];

const gradesData = [
  { subject: "رياضيات", avg: 78 },
  { subject: "عربي", avg: 85 },
  { subject: "علوم", avg: 72 },
  { subject: "إنجليزي", avg: 68 },
  { subject: "تاريخ", avg: 82 },
  { subject: "جغرافيا", avg: 76 },
];

const enrollmentData = [
  { month: "سبت", students: 1100 },
  { month: "أكت", students: 1150 },
  { month: "نوف", students: 1180 },
  { month: "ديس", students: 1190 },
  { month: "يناير", students: 1210 },
  { month: "فبر", students: 1230 },
];

const gradeDistribution = [
  { name: "ممتاز", value: 25, color: "#c9970c" },
  { name: "جيد جداً", value: 35, color: "#f5c518" },
  { name: "جيد", value: 25, color: "#a07808" },
  { name: "مقبول", value: 10, color: "#7a5a05" },
  { name: "راسب", value: 5, color: "#dc2626" },
];

const recentActivities = [
  { text: "تم نشر اختبار الرياضيات للصف الأول", time: "منذ 30 دقيقة", type: "exam" },
  { text: "تسليم واجب العلوم - 45 طالب", time: "منذ ساعة", type: "homework" },
  { text: "إعلان جديد: الاجتماع الأسبوعي", time: "منذ ساعتين", type: "announcement" },
  { text: "تسجيل حضور الصف الثاني ب", time: "منذ 3 ساعات", type: "attendance" },
  { text: "إضافة درس جديد: المعادلات التربيعية", time: "منذ 4 ساعات", type: "lesson" },
];

const activityIcons: Record<string, string> = {
  exam: "📝", homework: "📋", announcement: "📢", attendance: "✅", lesson: "📚"
};

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload?.length) {
    return (
      <div className="rounded-xl p-3 shadow-xl text-sm" style={{ background: "#0a0a0a", border: "1px solid rgba(184,134,11,0.3)", color: "#fff" }}>
        <p className="font-bold mb-1" style={{ color: "#c9970c" }}>{label}</p>
        {payload.map((p: any, i: number) => (
          <p key={i} style={{ color: p.color }}>{p.name}: {p.value}</p>
        ))}
      </div>
    );
  }
  return null;
};

export default function AdminDashboard() {
  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-up">
        {/* Header */}
        <div className="page-header">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-1 h-8 rounded-full" style={{ background: "linear-gradient(180deg, #f5c518, #a07808)" }} />
            <h1 className="page-title !mb-0">لوحة التحكم الإدارية</h1>
          </div>
          <p className="page-subtitle mr-4">نظرة شاملة على أداء المدرسة — {new Date().toLocaleDateString("ar-SA", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}</p>
        </div>

        {/* Stats Row 1 */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard title="إجمالي الطلاب" value="1,230" subtitle="في جميع الفصول"
            icon={<GraduationCap size={22} />} color="gold"
            trend={{ value: 5.2, label: "عن العام الماضي" }} />
          <StatCard title="المعلمون" value="82" subtitle="نشط هذا الفصل"
            icon={<Users size={22} />} color="green"
            trend={{ value: 3.1, label: "موظف جديد" }} />
          <StatCard title="الفصول الدراسية" value="36" subtitle="فصل نشط"
            icon={<BookOpen size={22} />} color="gold" />
          <StatCard title="الواجبات المعلقة" value="14" subtitle="بانتظار المراجعة"
            icon={<ClipboardList size={22} />} color="white" />
        </div>

        {/* Stats Row 2 */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard title="الاختبارات اليوم" value="5" subtitle="اختبارات نشطة"
            icon={<PenTool size={22} />} color="red" />
          <StatCard title="نسبة الحضور" value="94%" subtitle="هذا الأسبوع"
            icon={<Clock size={22} />} color="green" />
          <StatCard title="المتفوقون" value="312" subtitle="فوق 90%"
            icon={<Award size={22} />} color="gold" />
          <StatCard title="أولياء الأمور" value="890" subtitle="مسجل في المنصة"
            icon={<UserCheck size={22} />} color="white" />
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Attendance Chart */}
          <Card title="الحضور الأسبوعي" subtitle="الحضور والغياب يومياً" className="lg:col-span-2">
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={attendanceData} margin={{ top: 5, right: 0, left: -20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(184,134,11,0.08)" />
                <XAxis dataKey="day" tick={{ fontSize: 12, fontFamily: "Cairo", fill: "#888" }} />
                <YAxis tick={{ fontSize: 11, fill: "#888" }} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="present" name="حاضر" fill="#c9970c" radius={[6, 6, 0, 0]} />
                <Bar dataKey="absent" name="غائب" fill="rgba(220,38,38,0.5)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>

          {/* Grade Distribution Pie */}
          <Card title="توزيع الدرجات" subtitle="نسب التحصيل الدراسي">
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={gradeDistribution} cx="50%" cy="50%" outerRadius={75} dataKey="value" paddingAngle={3}>
                  {gradeDistribution.map((entry, i) => (
                    <Cell key={i} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ background: "#0a0a0a", border: "1px solid rgba(184,134,11,0.3)", borderRadius: "12px", color: "#fff", fontFamily: "Cairo" }} />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex flex-wrap gap-2 mt-2">
              {gradeDistribution.map((item) => (
                <div key={item.name} className="flex items-center gap-1.5 text-xs">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ background: item.color }} />
                  <span style={{ color: "hsl(var(--muted-foreground))" }}>{item.name} ({item.value}%)</span>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Grades & Enrollment */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Grades by Subject */}
          <Card title="متوسط الدرجات بالمواد" subtitle="المتوسط الحالي لكل مادة">
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={gradesData} layout="vertical" margin={{ left: 10, right: 10, top: 5, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(184,134,11,0.08)" horizontal={false} />
                <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 11, fill: "#888" }} />
                <YAxis dataKey="subject" type="category" width={65} tick={{ fontSize: 12, fontFamily: "Cairo", fill: "#888" }} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="avg" name="المتوسط" radius={[0, 6, 6, 0]}>
                  {gradesData.map((entry, i) => (
                    <Cell key={i} fill={entry.avg >= 80 ? "#c9970c" : entry.avg >= 70 ? "#f5c518" : "#a07808"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </Card>

          {/* Enrollment Trend */}
          <Card title="نمو عدد الطلاب" subtitle="خلال الفصل الدراسي الحالي">
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={enrollmentData} margin={{ top: 5, right: 0, left: -20, bottom: 5 }}>
                <defs>
                  <linearGradient id="goldGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#c9970c" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="#c9970c" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(184,134,11,0.08)" />
                <XAxis dataKey="month" tick={{ fontSize: 12, fontFamily: "Cairo", fill: "#888" }} />
                <YAxis tick={{ fontSize: 11, fill: "#888" }} />
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="students" name="الطلاب" stroke="#c9970c" strokeWidth={2.5} fill="url(#goldGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </Card>
        </div>

        {/* Recent Activities */}
        <Card title="آخر الأنشطة" subtitle="التحديثات الأخيرة في المنصة"
          action={
            <button className="text-xs font-bold flex items-center gap-1 transition-colors"
              style={{ color: "#c9970c" }}>
              عرض الكل <ArrowUpRight size={14} />
            </button>
          }>
          <div className="space-y-1">
            {recentActivities.map((activity, i) => (
              <div key={i} className="flex items-center gap-4 px-4 py-3.5 rounded-xl transition-colors cursor-pointer"
                onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = "hsl(var(--muted))"; }}
                onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = "transparent"; }}>
                <div className="w-9 h-9 rounded-xl flex items-center justify-center text-lg flex-shrink-0"
                  style={{ background: "rgba(184,134,11,0.08)" }}>
                  {activityIcons[activity.type]}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate" style={{ color: "hsl(var(--foreground))" }}>{activity.text}</p>
                </div>
                <span className="text-xs flex-shrink-0" style={{ color: "hsl(var(--muted-foreground))" }}>{activity.time}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </DashboardLayout>
  );
}
