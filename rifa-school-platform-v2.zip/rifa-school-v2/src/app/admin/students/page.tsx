"use client";

import { useState } from "react";
import DashboardLayout from "@/components/shared/DashboardLayout";
import { Card, Badge, Modal, EmptyState } from "@/components/ui/index";
import { Plus, Search, Filter, Download, Edit, Trash2, Eye, GraduationCap, User } from "lucide-react";

const mockStudents = [
  { id: "1", name: "أحمد محمد علي", studentNumber: "2024001", class: "الصف الأول أ", grade: "متوسط", age: 13, attendance: 95, avg: 87, status: "active" },
  { id: "2", name: "محمد عبدالله حسن", studentNumber: "2024002", class: "الصف الأول أ", grade: "متوسط", age: 13, attendance: 88, avg: 92, status: "active" },
  { id: "3", name: "عمر خالد محمود", studentNumber: "2024003", class: "الصف الثاني ب", grade: "متوسط", age: 14, attendance: 72, avg: 65, status: "active" },
  { id: "4", name: "يوسف سعد الدين", studentNumber: "2024004", class: "الصف الثالث أ", grade: "ثانوي", age: 15, attendance: 98, avg: 95, status: "active" },
  { id: "5", name: "عبدالرحمن فاروق", studentNumber: "2024005", class: "الصف الثاني أ", grade: "متوسط", age: 14, attendance: 60, avg: 55, status: "warning" },
];

export default function AdminStudents() {
  const [search, setSearch] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<typeof mockStudents[0] | null>(null);

  const filtered = mockStudents.filter(s =>
    s.name.includes(search) || s.studentNumber.includes(search) || s.class.includes(search)
  );

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="page-title">إدارة الطلاب 🎓</h1>
            <p className="page-subtitle">إجمالي {mockStudents.length} طالب مسجل</p>
          </div>
          <div className="flex gap-2">
            <button className="flex items-center gap-2 px-4 py-2.5 border border-gray-200 dark:border-gray-600 rounded-xl text-sm font-medium hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
              <Download size={16} /> تصدير
            </button>
            <button onClick={() => setShowAdd(true)}
              className="flex items-center gap-2 btn-primary text-sm py-2.5">
              <Plus size={16} /> إضافة طالب
            </button>
          </div>
        </div>

        {/* Filters */}
        <Card>
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input type="search" placeholder="البحث عن طالب..." value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="input-field pr-9 py-2" />
            </div>
            <select className="input-field py-2 sm:w-48">
              <option>جميع الفصول</option>
              <option>الصف الأول أ</option>
              <option>الصف الثاني ب</option>
            </select>
            <select className="input-field py-2 sm:w-48">
              <option>جميع المراحل</option>
              <option>متوسط</option>
              <option>ثانوي</option>
            </select>
          </div>
        </Card>

        {/* Students Table */}
        <div className="table-container overflow-x-auto">
          <table className="w-full min-w-[800px]">
            <thead>
              <tr className="border-b border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50">
                {["الطالب", "رقم الطالب", "الفصل", "الحضور", "المتوسط", "الحالة", "إجراءات"].map(h => (
                  <th key={h} className="px-4 py-3 text-right text-xs font-bold text-gray-500 dark:text-gray-400 uppercase">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50 dark:divide-gray-700/50">
              {filtered.map((student) => (
                <tr key={student.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center text-primary-600 dark:text-primary-400 font-bold">
                        {student.name[0]}
                      </div>
                      <div>
                        <div className="font-semibold text-gray-900 dark:text-white text-sm">{student.name}</div>
                        <div className="text-xs text-gray-400">{student.age} سنة</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-sm font-mono text-gray-600 dark:text-gray-400">{student.studentNumber}</td>
                  <td className="px-4 py-3">
                    <div className="text-sm text-gray-700 dark:text-gray-300">{student.class}</div>
                    <div className="text-xs text-gray-400">{student.grade}</div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-gray-100 dark:bg-gray-700 rounded-full h-1.5 w-20">
                        <div className={`h-full rounded-full ${student.attendance >= 90 ? "bg-emerald-500" : student.attendance >= 75 ? "bg-amber-500" : "bg-red-500"}`}
                          style={{ width: `${student.attendance}%` }} />
                      </div>
                      <span className="text-xs font-semibold text-gray-600 dark:text-gray-400">{student.attendance}%</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`font-bold text-sm ${student.avg >= 80 ? "text-emerald-600" : student.avg >= 60 ? "text-amber-600" : "text-red-600"}`}>
                      {student.avg}%
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <Badge variant={student.status === "active" ? "success" : "warning"}>
                      {student.status === "active" ? "نشط" : "تحذير"}
                    </Badge>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <button onClick={() => setSelectedStudent(student)}
                        className="p-1.5 rounded-lg hover:bg-blue-50 dark:hover:bg-blue-900/20 text-blue-500 transition-colors">
                        <Eye size={15} />
                      </button>
                      <button className="p-1.5 rounded-lg hover:bg-amber-50 dark:hover:bg-amber-900/20 text-amber-500 transition-colors">
                        <Edit size={15} />
                      </button>
                      <button className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 text-red-500 transition-colors">
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <EmptyState title="لا يوجد طلاب" description="لم يتم العثور على طلاب مطابقين للبحث"
              icon={<GraduationCap size={48} />} />
          )}
        </div>

        {/* Add Student Modal */}
        <Modal open={showAdd} onClose={() => setShowAdd(false)} title="إضافة طالب جديد" size="lg">
          <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); setShowAdd(false); }}>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">الاسم الكامل *</label>
                <input type="text" className="input-field" placeholder="أدخل الاسم" required />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">البريد الإلكتروني *</label>
                <input type="email" className="input-field text-left" placeholder="example@rifa.edu" dir="ltr" required />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">الفصل الدراسي *</label>
                <select className="input-field" required>
                  <option value="">اختر الفصل</option>
                  <option>الصف الأول أ</option>
                  <option>الصف الأول ب</option>
                  <option>الصف الثاني أ</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">تاريخ الميلاد</label>
                <input type="date" className="input-field text-left" dir="ltr" />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">رقم الهاتف</label>
                <input type="tel" className="input-field text-left" dir="ltr" placeholder="+966..." />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">كلمة المرور *</label>
                <input type="password" className="input-field text-left" dir="ltr" placeholder="كلمة مرور آمنة" required />
              </div>
            </div>
            <div className="flex gap-3 pt-2">
              <button type="submit" className="flex-1 btn-primary py-3">
                إضافة الطالب
              </button>
              <button type="button" onClick={() => setShowAdd(false)}
                className="flex-1 border border-gray-200 dark:border-gray-600 rounded-xl py-3 text-sm font-semibold hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                إلغاء
              </button>
            </div>
          </form>
        </Modal>

        {/* View Student Modal */}
        {selectedStudent && (
          <Modal open={!!selectedStudent} onClose={() => setSelectedStudent(null)}
            title={`ملف الطالب: ${selectedStudent.name}`} size="lg">
            <div className="space-y-6">
              <div className="flex items-center gap-4 p-4 bg-primary-50 dark:bg-primary-900/20 rounded-2xl">
                <div className="w-16 h-16 rounded-2xl bg-primary-100 dark:bg-primary-900/40 flex items-center justify-center text-primary-600 text-2xl font-black">
                  {selectedStudent.name[0]}
                </div>
                <div>
                  <h3 className="text-xl font-black text-gray-900 dark:text-white">{selectedStudent.name}</h3>
                  <div className="flex gap-2 mt-1">
                    <Badge variant="info">{selectedStudent.class}</Badge>
                    <Badge variant="default">{selectedStudent.grade}</Badge>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center p-4 bg-gray-50 dark:bg-gray-700 rounded-xl">
                  <div className="text-2xl font-black text-emerald-600">{selectedStudent.attendance}%</div>
                  <div className="text-xs text-gray-500 mt-1">نسبة الحضور</div>
                </div>
                <div className="text-center p-4 bg-gray-50 dark:bg-gray-700 rounded-xl">
                  <div className="text-2xl font-black text-blue-600">{selectedStudent.avg}%</div>
                  <div className="text-xs text-gray-500 mt-1">متوسط الدرجات</div>
                </div>
                <div className="text-center p-4 bg-gray-50 dark:bg-gray-700 rounded-xl">
                  <div className="text-2xl font-black text-purple-600">{selectedStudent.age}</div>
                  <div className="text-xs text-gray-500 mt-1">العمر (سنة)</div>
                </div>
              </div>
            </div>
          </Modal>
        )}
      </div>
    </DashboardLayout>
  );
}
