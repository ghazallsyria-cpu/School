"use client";
import { useState } from "react";
import DashboardLayout from "@/components/shared/DashboardLayout";
import { Card, Badge, Modal } from "@/components/ui/index";
import { Plus, Users, BookOpen, Edit, Trash2 } from "lucide-react";

const classes = [
  { id: "1", name: "الصف الأول أ", grade: "أول متوسط", students: 35, subjects: 8, teacher: "أ. خالد إبراهيم", year: "2024-2025" },
  { id: "2", name: "الصف الأول ب", grade: "أول متوسط", students: 33, subjects: 8, teacher: "أ. سارة محمود", year: "2024-2025" },
  { id: "3", name: "الصف الثاني أ", grade: "ثاني متوسط", students: 36, subjects: 9, teacher: "أ. محمد أحمد", year: "2024-2025" },
  { id: "4", name: "الصف الثاني ب", grade: "ثاني متوسط", students: 34, subjects: 9, teacher: "أ. فاطمة علي", year: "2024-2025" },
  { id: "5", name: "الصف الثالث أ", grade: "ثالث متوسط", students: 32, subjects: 10, teacher: "أ. عمر حسن", year: "2024-2025" },
  { id: "6", name: "الصف الثالث ب", grade: "ثالث متوسط", students: 30, subjects: 10, teacher: "أ. نورة أحمد", year: "2024-2025" },
];

const gradeColors: Record<string, string> = {
  "أول متوسط": "bg-blue-50 dark:bg-blue-900/20 border-blue-100 dark:border-blue-800",
  "ثاني متوسط": "bg-emerald-50 dark:bg-emerald-900/20 border-emerald-100 dark:border-emerald-800",
  "ثالث متوسط": "bg-purple-50 dark:bg-purple-900/20 border-purple-100 dark:border-purple-800",
};

export default function AdminClasses() {
  const [showAdd, setShowAdd] = useState(false);
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="page-title">الفصول الدراسية 🏫</h1><p className="page-subtitle">إجمالي {classes.length} فصل نشط</p></div>
          <button onClick={() => setShowAdd(true)} className="flex items-center gap-2 btn-primary text-sm py-2.5"><Plus size={16} /> إضافة فصل</button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {classes.map(cls => (
            <div key={cls.id} className={`rounded-2xl border p-5 shadow-sm card-hover ${gradeColors[cls.grade] || "bg-white dark:bg-gray-800 border-gray-100 dark:border-gray-700"}`}>
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="font-black text-gray-900 dark:text-white text-lg">{cls.name}</h3>
                  <Badge variant="info" className="mt-1">{cls.grade}</Badge>
                </div>
                <span className="text-2xl">🏫</span>
              </div>
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="text-center bg-white/60 dark:bg-gray-700/60 rounded-xl p-2.5"><div className="font-black text-gray-800 dark:text-gray-100">{cls.students}</div><div className="text-[10px] text-gray-400">طالب</div></div>
                <div className="text-center bg-white/60 dark:bg-gray-700/60 rounded-xl p-2.5"><div className="font-black text-gray-800 dark:text-gray-100">{cls.subjects}</div><div className="text-[10px] text-gray-400">مادة</div></div>
              </div>
              <div className="text-xs text-gray-500 dark:text-gray-400 mb-4">👨‍🏫 {cls.teacher}</div>
              <div className="flex gap-2">
                <button className="flex-1 flex items-center justify-center gap-1 py-2 border border-current/20 rounded-xl text-xs font-semibold text-gray-600 dark:text-gray-400 hover:bg-white/50 dark:hover:bg-gray-600/50 transition-colors"><Users size={12} /> الطلاب</button>
                <button className="px-3 py-2 border border-current/20 rounded-xl text-xs hover:bg-white/50 dark:hover:bg-gray-600/50 transition-colors text-gray-500"><Edit size={12} /></button>
                <button className="px-3 py-2 border border-red-200 dark:border-red-800/30 rounded-xl text-xs text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"><Trash2 size={12} /></button>
              </div>
            </div>
          ))}
        </div>
        <Modal open={showAdd} onClose={() => setShowAdd(false)} title="إضافة فصل دراسي" size="md">
          <form className="space-y-4" onSubmit={e => { e.preventDefault(); setShowAdd(false); }}>
            <div><label className="block text-sm font-semibold mb-1.5 text-gray-700 dark:text-gray-300">اسم الفصل *</label><input type="text" className="input-field" placeholder="الصف الأول ج" required /></div>
            <div className="grid grid-cols-2 gap-4">
              <div><label className="block text-sm font-semibold mb-1.5 text-gray-700 dark:text-gray-300">المرحلة *</label><select className="input-field" required><option value="">اختر</option><option>أول متوسط</option><option>ثاني متوسط</option><option>ثالث متوسط</option><option>أول ثانوي</option><option>ثاني ثانوي</option><option>ثالث ثانوي</option></select></div>
              <div><label className="block text-sm font-semibold mb-1.5 text-gray-700 dark:text-gray-300">المعلم الرئيسي</label><select className="input-field"><option>اختر المعلم</option><option>أ. محمد أحمد</option><option>أ. فاطمة علي</option></select></div>
            </div>
            <div className="flex gap-3"><button type="submit" className="flex-1 btn-primary py-3">إضافة الفصل</button><button type="button" onClick={() => setShowAdd(false)} className="flex-1 border border-gray-200 dark:border-gray-600 rounded-xl py-3 text-sm font-semibold hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">إلغاء</button></div>
          </form>
        </Modal>
      </div>
    </DashboardLayout>
  );
}
