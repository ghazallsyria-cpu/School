"use client";

import { Bell, Search, Sun, Moon, Settings } from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";

export default function TopBar() {
  const [darkMode, setDarkMode] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const { profile } = useAuth();

  const toggleDark = () => {
    setDarkMode(!darkMode);
    document.documentElement.classList.toggle("dark");
  };

  const notifications = [
    { text: "اختبار الرياضيات غداً الساعة 9 صباحاً", time: "منذ 30 د", type: "exam" },
    { text: "تم تصحيح واجب العلوم الخاص بك", time: "منذ ساعة", type: "homework" },
    { text: "إعلان جديد من إدارة المدرسة", time: "منذ 2 ساعة", type: "announcement" },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 lg:right-[var(--sidebar-width)] h-16 z-30 px-4 lg:px-6 flex items-center justify-between gap-4 topbar">
      {/* Search */}
      <div className="flex-1 max-w-sm hidden sm:block">
        <div className="relative">
          <Search size={15} className="absolute right-3 top-1/2 -translate-y-1/2" style={{ color: "#aaa" }} />
          <input
            type="search" placeholder="بحث في المنصة..."
            className="w-full rounded-xl pr-9 pl-4 py-2 text-sm text-right outline-none transition-all"
            style={{
              background: "hsl(var(--muted))",
              border: "1.5px solid hsl(var(--border))",
              color: "hsl(var(--foreground))",
            }}
            onFocus={(e) => { (e.target as HTMLElement).style.borderColor = "rgba(184,134,11,0.5)"; }}
            onBlur={(e) => { (e.target as HTMLElement).style.borderColor = "hsl(var(--border))"; }}
          />
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2 mr-auto">
        {/* Dark mode toggle */}
        <button onClick={toggleDark}
          className="w-9 h-9 rounded-xl flex items-center justify-center transition-all duration-200"
          style={{ background: "hsl(var(--muted))", border: "1px solid hsl(var(--border))", color: "hsl(var(--muted-foreground))" }}
          onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = "rgba(184,134,11,0.4)"; (e.currentTarget as HTMLElement).style.color = "#c9970c"; }}
          onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = "hsl(var(--border))"; (e.currentTarget as HTMLElement).style.color = "hsl(var(--muted-foreground))"; }}
        >
          {darkMode ? <Sun size={15} /> : <Moon size={15} />}
        </button>

        {/* Notifications */}
        <div className="relative">
          <button onClick={() => setNotifOpen(!notifOpen)}
            className="relative w-9 h-9 rounded-xl flex items-center justify-center transition-all duration-200"
            style={{ background: "hsl(var(--muted))", border: "1px solid hsl(var(--border))", color: "hsl(var(--muted-foreground))" }}
            onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = "rgba(184,134,11,0.4)"; (e.currentTarget as HTMLElement).style.color = "#c9970c"; }}
            onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = "hsl(var(--border))"; (e.currentTarget as HTMLElement).style.color = "hsl(var(--muted-foreground))"; }}
          >
            <Bell size={15} />
            <span className="absolute -top-0.5 -left-0.5 w-4 h-4 rounded-full text-white text-[9px] font-bold flex items-center justify-center"
              style={{ background: "#c9970c" }}>3</span>
          </button>

          {notifOpen && (
            <div className="absolute left-0 top-12 w-80 rounded-2xl shadow-2xl z-50 overflow-hidden animate-scale-in"
              style={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }}>
              <div className="px-5 py-4 flex items-center justify-between" style={{ borderBottom: "1px solid hsl(var(--border))" }}>
                <span className="font-black text-sm" style={{ color: "hsl(var(--foreground))" }}>الإشعارات</span>
                <span className="text-xs px-2 py-0.5 rounded-full font-bold"
                  style={{ background: "rgba(184,134,11,0.12)", color: "#c9970c" }}>3 جديد</span>
              </div>
              <div className="divide-y" style={{ borderColor: "hsl(var(--border))" }}>
                {notifications.map((n, i) => (
                  <div key={i} className="px-5 py-4 cursor-pointer transition-colors"
                    style={{ color: "hsl(var(--foreground))" }}
                    onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = "hsl(var(--muted))"; }}
                    onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = "transparent"; }}>
                    <p className="text-sm font-medium mb-1">{n.text}</p>
                    <p className="text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>{n.time}</p>
                  </div>
                ))}
              </div>
              <div className="px-5 py-3 text-center" style={{ borderTop: "1px solid hsl(var(--border))" }}>
                <span className="text-xs font-semibold cursor-pointer" style={{ color: "#c9970c" }}>عرض جميع الإشعارات</span>
              </div>
            </div>
          )}
        </div>

        {/* User pill */}
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl cursor-pointer transition-all duration-200"
          style={{ background: "hsl(var(--muted))", border: "1px solid hsl(var(--border))" }}>
          <div className="text-right hidden sm:block">
            <div className="text-xs font-bold leading-tight" style={{ color: "hsl(var(--foreground))" }}>
              {profile?.full_name?.split(" ")[0] || "مستخدم"}
            </div>
          </div>
          <div className="w-8 h-8 rounded-lg flex items-center justify-center font-black text-sm"
            style={{ background: "linear-gradient(135deg, #c9970c, #a07808)", color: "#fff" }}>
            {profile?.full_name?.[0] || "م"}
          </div>
        </div>
      </div>
    </header>
  );
}
