"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";
import {
  LayoutDashboard, Users, BookOpen, GraduationCap, FileText,
  ClipboardList, Bell, BarChart3, LogOut, Menu, X,
  Home, Clock, Library, PenTool, Award, UserCheck,
  Megaphone, FolderOpen, Calendar, Star, Shield, MessageSquare,
  ChevronLeft
} from "lucide-react";

interface NavItem { label: string; href: string; icon: React.ElementType; badge?: number; }

const adminNav: NavItem[] = [
  { label: "لوحة التحكم", href: "/admin", icon: LayoutDashboard },
  { label: "الطلاب", href: "/admin/students", icon: GraduationCap },
  { label: "المعلمون", href: "/admin/teachers", icon: Users },
  { label: "أولياء الأمور", href: "/admin/parents", icon: UserCheck },
  { label: "الفصول", href: "/admin/classes", icon: Home },
  { label: "المواد", href: "/admin/subjects", icon: BookOpen },
  { label: "الدروس", href: "/admin/lessons", icon: Library },
  { label: "الواجبات", href: "/admin/homework", icon: ClipboardList },
  { label: "الاختبارات", href: "/admin/exams", icon: PenTool },
  { label: "الحضور", href: "/admin/attendance", icon: Clock },
  { label: "الإعلانات", href: "/admin/announcements", icon: Megaphone },
  { label: "التقارير", href: "/admin/analytics", icon: BarChart3 },
];

const teacherNav: NavItem[] = [
  { label: "لوحة التحكم", href: "/teacher", icon: LayoutDashboard },
  { label: "فصولي", href: "/teacher/classes", icon: Home },
  { label: "الدروس", href: "/teacher/lessons", icon: Library },
  { label: "الواجبات", href: "/teacher/homework", icon: ClipboardList },
  { label: "الاختبارات", href: "/teacher/exams", icon: PenTool },
  { label: "بنك الأسئلة", href: "/teacher/questions", icon: FolderOpen },
  { label: "الحضور", href: "/teacher/attendance", icon: Clock },
  { label: "الإعلانات", href: "/teacher/announcements", icon: Megaphone },
  { label: "أداء الطلاب", href: "/teacher/performance", icon: BarChart3 },
];

const studentNav: NavItem[] = [
  { label: "لوحة التحكم", href: "/student", icon: LayoutDashboard },
  { label: "دروسي", href: "/student/lessons", icon: Library },
  { label: "الواجبات", href: "/student/homework", icon: ClipboardList },
  { label: "الاختبارات", href: "/student/exams", icon: PenTool },
  { label: "جدولي", href: "/student/schedule", icon: Calendar },
  { label: "درجاتي", href: "/student/grades", icon: Award },
  { label: "الإعلانات", href: "/student/announcements", icon: Bell },
];

const parentNav: NavItem[] = [
  { label: "لوحة التحكم", href: "/parent", icon: LayoutDashboard },
  { label: "الدرجات", href: "/parent/grades", icon: Award },
  { label: "نتائج الاختبارات", href: "/parent/exam-results", icon: Star },
  { label: "الحضور", href: "/parent/attendance", icon: Clock },
  { label: "الإعلانات", href: "/parent/announcements", icon: Bell },
  { label: "التواصل", href: "/parent/messages", icon: MessageSquare },
];

const roleConfig = {
  admin: { label: "مدير النظام", icon: Shield, color: "#c9970c" },
  teacher: { label: "معلم", icon: BookOpen, color: "#c9970c" },
  student: { label: "طالب", icon: GraduationCap, color: "#c9970c" },
  parent: { label: "ولي أمر", icon: UserCheck, color: "#c9970c" },
};

export default function Sidebar() {
  const [open, setOpen] = useState(false);
  const { profile, role, signOut } = useAuth();
  const pathname = usePathname();

  const navItems = role === "admin" ? adminNav
    : role === "teacher" ? teacherNav
    : role === "parent" ? parentNav
    : studentNav;

  const config = roleConfig[role || "student"];
  const RoleIcon = config.icon;

  const SidebarContent = () => (
    <div className="flex flex-col h-full scrollbar-thin" style={{ overflowY: "auto" }}>
      {/* Header */}
      <div className="p-5 text-white" style={{ borderBottom: "1px solid rgba(184,134,11,0.15)" }}>
        {/* Logo */}
        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: "linear-gradient(135deg, #c9970c, #a07808)", boxShadow: "0 4px 12px rgba(184,134,11,0.4)" }}>
            <span className="text-white text-lg font-black">ر</span>
          </div>
          <div>
            <div className="text-white text-sm font-black leading-tight">مدرسة الرفعة</div>
            <div className="text-xs font-medium" style={{ color: "#666" }}>النموذجية</div>
          </div>
        </div>

        {/* Gold divider */}
        <div className="gold-divider mb-5" />

        {/* User Info */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm flex-shrink-0"
            style={{ background: "rgba(184,134,11,0.15)", border: "1.5px solid rgba(184,134,11,0.3)", color: "#c9970c" }}>
            {profile?.full_name?.[0] || "م"}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-white text-sm font-bold truncate">{profile?.full_name || "المستخدم"}</div>
            <div className="flex items-center gap-1.5 mt-0.5">
              <RoleIcon size={11} style={{ color: "#c9970c" }} />
              <span className="text-xs font-medium" style={{ color: "#888" }}>{config.label}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-1">
        <div className="text-xs font-bold mb-3 px-4" style={{ color: "#444", letterSpacing: "0.08em" }}>
          القائمة الرئيسية
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = pathname === item.href;
          return (
            <Link key={item.href} href={item.href}
              onClick={() => setOpen(false)}
              className={`nav-item ${isActive ? "active" : ""}`}>
              <Icon size={17} />
              <span className="flex-1 text-sm">{item.label}</span>
              {item.badge && (
                <span className="text-xs font-bold px-1.5 py-0.5 rounded-full"
                  style={{ background: "rgba(184,134,11,0.2)", color: "#c9970c" }}>
                  {item.badge}
                </span>
              )}
              {isActive && <ChevronLeft size={14} style={{ color: "#c9970c" }} />}
            </Link>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="p-4" style={{ borderTop: "1px solid #1a1a1a" }}>
        <button onClick={signOut}
          className="flex items-center gap-3 w-full px-4 py-3 rounded-xl text-sm font-semibold transition-all duration-200"
          style={{ color: "#666" }}
          onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = "rgba(220,38,38,0.08)"; (e.currentTarget as HTMLElement).style.color = "#ef4444"; }}
          onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = "transparent"; (e.currentTarget as HTMLElement).style.color = "#666"; }}
        >
          <LogOut size={16} />
          <span>تسجيل الخروج</span>
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop */}
      <div className="sidebar hidden lg:block">
        <SidebarContent />
      </div>

      {/* Mobile toggle */}
      <button onClick={() => setOpen(true)}
        className="lg:hidden fixed top-4 right-4 z-50 w-11 h-11 rounded-xl flex items-center justify-center shadow-lg"
        style={{ background: "#0a0a0a", border: "1px solid rgba(184,134,11,0.3)", color: "#c9970c" }}>
        <Menu size={20} />
      </button>

      {/* Mobile overlay */}
      {open && (
        <div className="lg:hidden fixed inset-0 z-40">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setOpen(false)} />
          <div className="absolute top-0 right-0 h-full sidebar open" style={{ width: "var(--sidebar-width)" }}>
            <button onClick={() => setOpen(false)}
              className="absolute top-4 left-4 w-8 h-8 rounded-lg flex items-center justify-center z-10"
              style={{ background: "rgba(255,255,255,0.08)", color: "#888" }}>
              <X size={16} />
            </button>
            <SidebarContent />
          </div>
        </div>
      )}
    </>
  );
}
